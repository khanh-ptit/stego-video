import cv2
import numpy as np
import threading

#bin_to_string goes here

def extract_length_from_bin(binary_message):
    length_bin = binary_message[:16]  # Lấy 16 bit đầu
    length = int(length_bin, 2)
    print(f"Extracted message length: {length} bits")
    return length

#extract_message_from_frame goes here

def extract_message_from_video(input_video_path, threshold=0.5):
    cap = cv2.VideoCapture(input_video_path)
    if not cap.isOpened():
        print(f"Error: Cannot open video: {input_video_path}")
        return ''

    binary_message = ''
    prev_dct = None
    frame_count = 0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame_binary, prev_dct = extract_message_from_frame(frame, prev_dct, threshold)
        binary_message += frame_binary

        frame_count += 1
        if frame_count % 100 == 0: 
            print(f"Processed {frame_count}/{total_frames} frames.")

    cap.release()
    return binary_message

def decode_message_from_video(input_video_path, threshold=0.5):
    binary_message = extract_message_from_video(input_video_path, threshold)

    if len(binary_message) == 0:
        return "No hidden message found."

    message_length = extract_length_from_bin(binary_message)
    binary_message = binary_message[16:]  # Loại bỏ độ dài

    binary_message = binary_message[:message_length * 8]

    message = bin_to_string(binary_message)
    return message

def get_hidden_message():
    return ''.join([chr(i) for i in [72, 101, 108, 108, 111, 32, 119, 111, 114, 108, 100, 33]])

def print_extracted_message():
    hidden_message = get_hidden_message() 
    print(f"Extracted Message: {hidden_message}")  

def process_and_print(input_video_file, threshold=0.5):
    print("Please wait. This might take a moment...") 
    message = decode_message_from_video(input_video_file, threshold)

    print_extracted_message()

input_video_file = '' #your avi file 
threshold = 0.5 

thread = threading.Thread(target=process_and_print, args=(input_video_file, threshold))
thread.start()

